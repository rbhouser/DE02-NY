use CDW_SAPP;

select * from CDW_SAPP_CUSTOMER
where cast(CREDIT_CARD_NO AS unsigned) > 4210653399939240;

select 
SSN AS CUST_SSN,
if (lower(substring(FIRST_NAME,1,1)) = substring(FIRST_NAME,1,1), concat(upper(substring(FIRST_NAME,1,1)), substring(FIRST_NAME,2)),FIRST_NAME) CUST_F_NAME,
lower(MIDDLE_NAME) MIDDLE_NAME,
if (lower(substring(LAST_NAME,1,1)) = substring(LAST_NAME,1,1), concat(upper(substring(LAST_NAME,1,1)), substring(LAST_NAME,2)),LAST_NAME) CUST_L_NAME,
CREDIT_CARD_NO,
concat(STREET_NAME, ' ', APT_NO) CUST_STREET,
CUST_CITY,
CUST_STATE,
CUST_COUNTRY,
CAST(CUST_ZIP AS UNSIGNED) CUST_ZIP,
concat(substring(CUST_PHONE,1,3),'-',substring(CUST_PHONE,4)) CUST_PHONE, 
CUST_EMAIL,
LAST_UPDATED
from CDW_SAPP_CUSTOMER
where cast(CREDIT_CARD_NO AS unsigned) > 4210653399939240;

 

