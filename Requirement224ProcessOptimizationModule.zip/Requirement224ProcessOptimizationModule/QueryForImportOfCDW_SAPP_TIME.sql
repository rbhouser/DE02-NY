use CDW_SAPP;

select count(*) from CDW_SAPP_CREDITCARD;

select
CREDIT_CARD_NO,
concat(YEAR, lpad(MONTH, 2, 0), lpad(DAY, 2, 0)) TIMEID,
lpad(DAY, 2, 0) DAY,
lpad(MONTH, 2, 0) MONTH,
case
when MONTH < 1 then null
when MONTH < 4 then 'Quarter1'
when MONTH < 7 then 'Quarter2'
when MONTH < 10 then 'Quarter3'
when MONTH < 13 then 'Quarter4'
else NULL END AS QUARTER,
YEAR
FROM CDW_SAPP_CREDITCARD
where cast(CREDIT_CARD_NO AS unsigned) > 4210653399939200
Order by CREDIT_CARD_NO desc
LIMIT 100;