/*
 * ----------------------------------------------------------------------------------------------------------------------------------------------------------
 * Name: Robert B. Houser
 * Date Due: June 25, 2016
 * Course: Data Engineering
 * Project: Case Study  
 * 
 * File: Report Transaction Data
 * 
 * ----------------------------------------------------------------------------------------------------------------------------------------------------------
*/

/* This Processor is the solution to satisfy Functional Requirement 2.1.1 - Transaction Detail Module
 * It is responsible for producing the following activities
 * 1) Display the transactions made by customers living in a given zipcode for a given month and year.
 *    by date in descending order. 
 * 2) Display the number and total values of transactions for a given type.
 * 3) Display the number and total values of transactions for branches in a given state.
 * 
 */

	package od_cdw_sapp;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
import java.text.DateFormatSymbols;
import java.util.Scanner;
	
	public class ProcessCustomerDetail {
	/*
	 * An instance of the Process Customer Detail performs the following activities.  They are:
	 * 1. Display Report Menu and ask the End-user for the report request number
	 * 2. Initiate a MySQL database connection
	 * 3. Invoke a CreateStatement instance
	 * 4. Execute the query
	 * 5. Display the report or modify existing records
	 * 6. Close ends the MySQL database connection
	 */

		// JDBC objects and variables
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String database = "CDW_SAPP";
		String user = "root";
		String password = "password";
		String connection = "jdbc:mysql://localhost:3306/+ database +?useSSL=false";
		String SQL = "";
		
		// Processing status variables
		boolean notFinished = true;
		// Report number selected n=by End-user
		int reportNumber = 0;
		//Reports the outcome of a JDBC activity
		int outcomeOfQuery = 0;
		
		// Parameters for reports
		int socialSecurity = 0;
		int month = 0;
		int year = 0;
		int dayBegin = 0;
		int dayEnd = 0;
		int monthBegin = 0;
		int monthEnd = 0;
		String creditCard = "";
		
		// Report variables
		int dateBegin = Integer.valueOf(String.valueOf(year) + String.valueOf(monthBegin) + String.valueOf(dayBegin));
		int dateEnd = Integer.valueOf(String.valueOf(year) + String.valueOf(monthEnd) + String.valueOf(dayEnd));
		int rowCount = 0;
		
		// Manages the report data processing flow.
		public int managePCD(){
					
			/* This method coordinates the overall processing follow starting with the
			 * asking the End-user to choose between requesting a report through ending the 
			 * processing flow. 
			 */
			do {
				int outCome = 0;
				/* Step A - Request report number from End-user
				 * If the ENd-user enters 0, processing ends and control returns to the main process. 
				 */
				String menu_message = "\n\nAvailable Transaction Requests are: "
						+ "Number\tName"
						+ "\n1. View Customer Information "
						+ "\n2. Modify Customer Information"
						+ "\n3. Publish Credit Card Bill"
						+ "\n4. View Transaction For Time Period By Customer"
						+ "\n0. Finished"
						+ "\n\nEnter selected menu number: ";
				
				reportNumber = requestReportOrModifyInformation(menu_message);
				System.out.println("\n\nThe selected report number is " + reportNumber);
				
				if ((reportNumber >= 0) && (reportNumber < 3)){
					notFinished = true;
					System.out.println("End-user selected a report.");
				} else {
					// End-user chose to exit.
					notFinished = false;
					break;
				} 
	
				/* Step B - Get report parameters from End-user
				 * Depending on the deliverable, the process shall request parameters 
				 * which are the inputs to a query from the End-user.
				 * 
				 * Depending on the case, the parameters are necessary to retrieve the
				 * information from the database or modify customer information.
				 * 
				 * The each case method performs data entry validation.
				 *  
				 */
				switch (reportNumber){
				// View Customer Information
				// Get social security number			
				case 1: 
					socialSecurity = requestSSN("Enter - social security number");  
					break;
						
				// Modify Customer Information	
				// Get social security number
				case 2: 
					socialSecurity = requestSSN("Enter - social security number");
					break;
						
				// Publish Credit Card Bill
				// Get month, year, and credit-card from End-user					
				case 3: 
					month = requestMonth("Enter month: "); 
					year = requestYear("Enter year: ");
					creditCard = requestCreditCardNumber("Enter credit card number: ");
					break;
	
				// View Transaction For Time Period By Customer
				// Get the customer Credit Card and the beginning and ending month
				case 4:
					creditCard = requestCreditCardNumber("Enter credit card number: ");
					year = requestYear("Enter year: ");
					monthBegin = requestMonth("Enter beginng month as a number between 1 and 12: "); 
					monthEnd = requestMonth("Enter ending month as a number between 1 and 12: ");
					dayBegin = requestDay("Enter beginning date as a number between 1 and 31  ", year);
					dayEnd = requestDay("Enter ending date as a number between 1 and 31 : ", year);
					break;
					
				default: System.out.println("System processing error in processing");
				  break;							  
			}
	
				// Step C - Connect to database and perform report activity
				outCome = performQueryWithJDBC();
				
				/* Step D - Determine if process successfully completed it activity
				 * If process performed the desired activity, display menu for user to choose next action
				 * If process did not successfully complete action, inform the user of problem and exist
				 * close process.
				 */
				if (outcomeOfQuery > 0) {
					notFinished = true;
				}
				
			}while (notFinished == false);
			return outcomeOfQuery;
		}
		
		/* Display Customer Detail Selection Menu and retrieves the 
		 * action request number from the End-user.
		 * This process is active to accept request and displays the
		 * menu until the End-user enters 0 as the number which indicates
		 * the End-user is finished. 
		 * 
		 * The requestReportOrModifyInformation method performs report
		 * number data entry validation.
		 */
		public int requestReportOrModifyInformation(String message) {
			boolean selectedReport = false;
			System.out.print(message);
			Scanner input = new Scanner(System.in);
	    	int inputReportNumber = 0;
			do {
		    	inputReportNumber = input.nextInt();
		    	if ((reportNumber > 0) && (reportNumber < 4)) {
		    		selectedReport = true;
		    	} else {
		    		System.out.println("SSN value must be nine(9) digits");
		    	}
			}while(selectedReport == false);
		    return inputReportNumber;
		}
	
		// Retrieve the social security number (SSN) from the End-user.
		public static int requestSSN(String message) {
			boolean validSSN = false;
			System.out.println(message);
			Scanner inputInt = new Scanner(System.in);
	    	int inputSSN = 0;
		    do {
		    	inputSSN = inputInt.nextInt();
		    	if (inputSSN < 999999999) {
		    		validSSN = true;
		    	} else {
		    		System.out.println("SSN value must be nine(9) digits");
		    	}
			}while(validSSN == false);
		    return inputSSN;
		}

		//Retrieves the date in the calendar month from the End-user.
		public static int requestDay(String message, int inputYear) {
			System.out.println(message);
			Scanner inputInt = new Scanner(System.in);
			boolean validDay = false;
	    	int inputDay;
		    do {
		    	System.out.println(message);
		    	inputDay = inputInt.nextInt();
		    	if ((inputDay > 0) && inputDay <31) {
		    		validDay = true;
		    	} else if ((inputYear %4 != 0 && (inputDay < 1) || inputDay > 28)) {
		    		System.out.println("For month the value must be between 1 and 12");
		    	}
			}while(validDay == false);
		    return inputDay;
		}		
		
		//Retrieves the calendar month from the End-user.
		public static int requestMonth(String message) {
			System.out.println(message);
			Scanner inputInt = new Scanner(System.in);
			boolean validMonth = false;
	    	int inputMonth;
		    do {
		    	System.out.println(message);
		    	inputMonth = inputInt.nextInt();
		    	if ((inputMonth > 0) && inputMonth <13) {
		    		validMonth = true;
		    	} else {
		    		System.out.println("For month the value must be between 1 and 12");
		    	}
			}while(validMonth == false);
		    return inputMonth;
		}
	
		//Retrieves the year from the End-user.
		public static int requestYear(String message) {
			System.out.println(message);
			Scanner inputInt = new Scanner(System.in);
			boolean validYear = false;
			int inputYear;
		    do {
		    	System.out.println(message);
		    	inputYear = inputInt.nextInt();
		    	if (inputYear > 2000)  {
		    		validYear = true;
		    	} else {
		    		System.out.println("For month the value must be between 1 and 12");
		    	}
			}while(validYear == false);
		    return inputYear;
		}
		
		//Retrieves the credit card number from the End-user.
		public static String requestCreditCardNumber(String message) {
			System.out.println(message);
			Scanner inputString = new Scanner(System.in);
			boolean validCreditCard = false;
	    	String inputCreditCard;
		    do {
		    	System.out.println(message);
		    	inputCreditCard = inputString.next();
		    	if (inputCreditCard.length() < 16) {
		    		validCreditCard = true;
		    	} else {
		    		System.out.println("For month the value must be between 1 and 12");
		    	}
			}while(validCreditCard == false);
		    return inputCreditCard;
		}

		// Convert integer to month name
		public String getMonth(int month) {
		    return new DateFormatSymbols().getMonths()[month-1];
		}
		
		/* Performs activities to query or modify the information in
		 * the CDW_SAPP
		 */
		public int performQueryWithJDBC() {
		
		    try {
				/* Step 1 - Allocate a database 'Connection' object 
				 * MySQL: "jdbc:mysql://hostname:port/databaseName", "username", "password"
				 */
				conn = DriverManager.getConnection(connection, user, password);
				System.out.println("Database connection successful!! \n"); 
				
				
				/* Step 2 - Allocate a 'Statement' object in the Connection
				     * This process uses a prepareStatement object to create the select and update statements in order to 
				     * retrieve the desired information or updated the customer information. Inside of the case block, a tag
				     *  marks the code for Step 2.
				     */

				/* Step 3 - Execution of the prepared statement occurs through the ExecuteQuery method of the ResultSet rs object
				 * statement submission of the SQL SELECT or the UPDATE statement. Inside of the case block, a tag marks the code
				 *  for Step 3.
				 */
				
				/* Step 4 - The statements in the while block map the returned data in the ResultSet by 
				 * scrolling the cursor forward via next().  For each row, retrieve the contents of the cells with 
				 * getXxx(columnName) are assigned to a variable. Inside of the case block, a tag marks the code for Step 4.
				 */
				
				switch(reportNumber) {
				// Query and retrieve results for View Customer Information
				case 1:		    			
					// Step 2
					SQL = "select FIRST_NAME, MIDDLE_NAME, LAST_NAME, SSN, CREDIT_CARD_NO,"
							+ " APT_NO, STREET_NAME,CUST_CITY, CUST_STATE, CUST_COUNTRY, CUST_ZIP,"
							+ " CUST_PHONE, CUST_EMAIL, LAST_UPDATED "
						+ " from CDW_SAPP_CUSTOMER"
						+ " where SSN = ?";
					
					// Echo For debugging
					System.out.println("The SQL query is: " + SQL); 
					System.out.println();
					// Remove statements above before going into production
					
					pstmt = conn.prepareStatement(SQL);
					pstmt.setString(1, creditCard);
					pstmt.setInt(2, dateBegin);
					pstmt.setInt(3, dateEnd);
					
					// Step 3
					rs = pstmt.executeQuery();
					
					//Step 4
					System.out.println("The record selected is:");
					rowCount = 0;
					while(rs.next()) {   // Move the cursor to the next row, return false if no more row
						String fname = rs.getString("FIRST_NAME");
						String mname = rs.getString("MIDDLE_NAME");
						String lname = rs.getString("LAST_NAME");
						int social = rs.getInt("SSN");
						String ccNumber = rs.getString("CREDIT_CARD_NO");
						String apt = rs.getString("APT_NO");
						String street = rs.getString("STREET_NAME");
						String city = rs.getString("CUST_CITY");
						String state = rs.getString("CUST_STATE");
						String country = rs.getString("CUST_COUNTRY");
						String zip = rs.getString("CUST_ZIP");
						int phone = rs.getInt("CUST_PHONE");
						String email = rs.getString("CUST_EMAIL");
						java.sql.Timestamp update = rs.getTimestamp("LAST_UPDATED");							  
						 
						System.out.println("\n" + fname + ", " + mname + ", " + lname
						+ ", "  + social + ", "  + ccNumber + ", "  + apt
						+ ", " + "\n" + street + ", " + city + ", " + state + ", " + country  + ", " + zip
						+ ", " + phone + ", " + email + ", " + update);
						++rowCount;
					}
					System.out.println("\n\nTotal number of records = " + rowCount);
					break;
				
				// Modify customer information
				case 2:
					// Step 2
					SQL = "select FIRST_NAME, MIDDLE_NAME, LAST_NAME, SSN, CREDIT_CARD_NO,"
							+ " APT_NO, STREET_NAME,CUST_CITY, CUST_STATE, CUST_COUNTRY, CUST_ZIP,"
							+ " CUST_PHONE, CUST_EMAIL, LAST_UPDATED "
						+ "from cdw_sapp_customer"
						+ "where SSN = ?";
					
					// Echo For debugging
					System.out.println("The SQL query is: " + SQL); 
					System.out.println();
					// Remove statements above before going into production
					
					pstmt = conn.prepareStatement(SQL);
					pstmt.setInt(1, socialSecurity);
					
					// Step 3
					rs = pstmt.executeQuery();
					
					//Step 4
					System.out.println("The record selected is:");
					System.out.println("The record selected is:");
					rowCount = 0;
					while(rs.next()) {   // Move the cursor to the next row, return false if no more row
						String fname = rs.getString("FIRST_NAME");
						String mname = rs.getString("MIDDLE_NAME");
						String lname = rs.getString("LAST_NAME");
						int social = rs.getInt("SSN");
						String ccNumber = rs.getString("CREDIT_CARD_NO");
						String apt = rs.getString("APT_NO");
						String street = rs.getString("STREET_NAME");
						String city = rs.getString("CUST_CITY");
						String state = rs.getString("CUST_STATE");
						String country = rs.getString("CUST_COUNTRY");
						String zip = rs.getString("CUST_ZIP");
						int phone = rs.getInt("CUST_PHONE");
						String email = rs.getString("CUST_EMAIL");
						java.sql.Timestamp update = rs.getTimestamp("LAST_UPDATED");							  
						 
						System.out.println("\n" + fname + ", " + mname + ", " + lname
						+ ", "  + social + ", "  + ccNumber + ", "  + apt
						+ ", " + "\n" + street + ", " + city + ", " + country  + ", " + zip
						+ ", " + phone + ", " + email + ", " + update);
						++rowCount;
					}
					System.out.println("\n\nTotal number of records = " + rowCount);

					 
					// Placeholder for Modify fields process
					
					break;
					 
				// Create monthly bill details
				case 3:
					// Step 2
					SQL = "select  TRANSACTION_ID, concat(YEAR, MONTH, DAY) TRANSACTION_DATE,"
							+ " TRANSACTION_TYPE, TRANSACTION_VALUE"
							+ " from CDW_SAPP_CREDITCARD "
							+ " where CREDIT_CARD_NO = ? AND year = ? AND MONTH = ?";
					
					pstmt = conn.prepareStatement(SQL);
					pstmt.setString(1, creditCard);
					pstmt.setInt(2, year);
					pstmt.setInt(3, month);

					// Echo For debugging
					System.out.println("The SQL query is: " + SQL); 
					System.out.println();
					// Remove statements above before going into production
					
					// Step 3
					rs = pstmt.executeQuery();
					 
					// Step 4
					System.out.println("Bill transaction details for " + creditCard);
					 rowCount = 0;
					 while(rs.next()) {   // Move the cursor to the next row, return false if no more row
						 String id = rs.getString("TRANSACTION_ID");
						 String serviceDate = rs.getString("TRANSACTION_DATE");
						 String type = rs.getString("TRANSACTION_TYPE");
						 double value =rs.getDouble("TRANSACTION_VALUE");
						 
						 System.out.println("Bill transaction details for " + id);
					     System.out.println(id + ", " + serviceDate + ", " + type + ", "  + value);
				     ++rowCount;
					 }
					 System.out.println("Total number of records = " + rowCount);
					 break;  			
				
				// Display transactions between two dates for a customer's credit card
				case 4:
					// Step 2
					SQL = "select TRANSACTION_ID, concat(YEAR, LPAD(MONTH,2,0), LPAD(DAY,2,0)) as TRANSACTION_DATE, TRANSACTION_TYPE, TRANSACTION_VALUE " + 
							" from CDW_SAPP_CREDITCARD " + 
							" where cast(CREDIT_CARD_NO AS unsigned) = ? AND concat(YEAR, MONTH, DAY) > ? AND concat(YEAR, MONTH, DAY) < ? " + 
							" order by YEAR desc, MONTH desc ";
					
					pstmt = conn.prepareStatement(SQL);
					pstmt.setString(1, creditCard);
					pstmt.setInt(2, dateBegin);
					pstmt.setInt(3, dateEnd);

					
					// Step 3
					rs = pstmt.executeQuery();
					
					// Step 4
					 
					 // Process the ResultSet by scrolling the cursor forward via next().
					 // For each row, retrieve the contents of the cells with getXxx(columnName).
					 System.out.println("The records selected are:");
					 rowCount = 0;
					 while(rs.next()) {   // Move the cursor to the next row, return false if no more row
						 String id = rs.getString("TRANSACTION_ID");
						 String serviceDate = rs.getString("TRANSACTION_DATE");
						 String type = rs.getString("TRANSACTION_TYPE");
						 double value =rs.getDouble("TRANSACTION_VALUE");

						 String startMonth = getMonth(monthBegin);
						 String endMonth = getMonth(monthEnd);
						 
						 System.out.println("Transaction details from " + startMonth + " " + " to " + endMonth + " in " + year + " are:\n");
						 System.out.println(id + ", " + serviceDate + ", " + type + ", "  + value);				     ++rowCount;
					 }
					 System.out.println("Total number of records = " + rowCount);
					 break;  			
					 
					 
				default:
					// If you arrived here, an error exist, leave the process
						break;
						
					}
					return outcomeOfQuery = 1;
				 } catch(SQLException ex) {
				    ex.printStackTrace();
				    return outcomeOfQuery = 0;
				 } finally {
				     // Step 5: Close the resources - Hopefully done automatically by try-with-resources
						try {
							if (rs != null) {
								rs.close();
							}
							
							if (pstmt != null) {
								pstmt.close();
							}
							
							if (conn != null) {
								conn.close();
							}
						} catch (Exception exc) {
							exc.printStackTrace();
						  }
				 }
	
		      }
	
}
