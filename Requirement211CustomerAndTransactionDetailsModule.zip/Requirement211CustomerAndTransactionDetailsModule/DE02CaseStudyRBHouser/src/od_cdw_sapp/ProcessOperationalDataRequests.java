package od_cdw_sapp;

import java.util.Scanner;

public class ProcessOperationalDataRequests {

	public static void main(String[] args) {
		int outcomePTD = 0;
		int outcomePCD = 0;
		boolean keepActive = false;
		int processNumber = 0;

		// This process is active to accept request and displays the menu until the User enters 0 as the number
		do {
				// Step 1 - Determine if End-User has a request
				processNumber = GetProcessSelection();
				if (processNumber == 0) {
					break;
				}
				else if ((processNumber >= 0) && (processNumber < 3)){
						keepActive = true;
				}else {
					System.out.println("The requested number is not valid");
				}
		
				// Step 2 - Select and Initiate Customer Detail processing or Transaction Detail processing
				switch (processNumber) {
					case 1: ProcessCustomerDetail procPCD = new ProcessCustomerDetail(); 
	 				procPCD.managePCD(); 
					break;	
					
					case 2: 
						System.out.println("Perform Customer Detail processing\n\n"); 
						ProcessTransactionDetail procPTD = new ProcessTransactionDetail(); 
		 				procPTD.managePTD(); 
						break;							
				}
				
				if ((outcomePCD == 0) && (outcomePTD == 0)){
					System.out.println("Perform Customer Detail processing Finished\n\n");
					keepActive = true;
				}
				
			}while (keepActive == true);
		}
				
		static public int GetProcessSelection() {
			boolean selectedRequest = false;
			int requestNumber;
			
			// Main Menu
			String menu_message = "Welcome to the Operational Database\n"
					+ "Number \t Request\n"
					+ "1\tView or modify Customer Details\n"
					+ "2\tRequest Transaction Detail Report\n"
					+ "0\tEndProcessing\n"
					+ "Enter your number selection: ";

			do {
				Scanner input = new Scanner(System.in);
				System.out.print(menu_message);
				requestNumber = input.nextInt();
				if (requestNumber == 0) {
					System.out.println("Processing stopped as requested by End-user");
					break;
				}
				else if ((requestNumber >= 0) && (requestNumber < 3)){
						selectedRequest = true;
				}else {
					System.out.println("A requested number is not valid");
				}
			}while (selectedRequest == false);
			return requestNumber;
		}		
}
