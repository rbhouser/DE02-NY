/*
 * ----------------------------------------------------------------------------------------------------------------------------------------------------------
 * Name: Robert B. Houser
 * Date Due: June 25, 2016
 * Course: Data Engineering
 * Project: Case Study  
 * 
 * File: Report Transaction Data
 * 
 * ----------------------------------------------------------------------------------------------------------------------------------------------------------
*/

/* This Processor is the solution to satisfy Functional Requirement 2.1.1 - Transaction Detail Module
 * It is responsible for producing the following activities
 * 1) Display the transactions made by customers living in a given zipcode for a given month and year.
 *    by date in descending order. 
 * 2) Display the number and total values of transactions for a given type.
 * 3) Display the number and total values of transactions for branches in a given state.
 * 
 */

package od_cdw_sapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormatSymbols;
import java.util.Scanner;

public class ProcessTransactionDetail {
	
/*
 * This constructor creates an instance of the Process Flow Coordinator which performs the following activities.  They are:
 * 1. Display Report Menu and ask the End-user for the report request number
 * 2. Initiate a MySQI database connection
 * 3. Invoke a CreateStatement instance
 * 4. Execute the query
 * 5. Display the report
 * 6. Close ends the MySQL database connection
 */

	// JDBC objects and variables
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String database = "CDW_SAPP";
	String user = "root";
	String password = "password";
	String connection = "jdbc:mysql://localhost:3306/" + database + "?useSSL=false";
	String SQL = "";
	
	// Processing status variables
	boolean notFinished = true;
	// Report number selected n=by End-user
	int reportNumber = 0;
	//Reports the outcome of a JDBC activity
	int outcomeOfQuery = 0;

	// Parameters for reports
	int socialSecurity = 0;
	String creditCard = "";
	int month = 0;
	int year = 0;
	int dayBegin = 0;
	int dayEnd = 0;
	int monthBegin = 0;
	int monthEnd = 0;
	int zipCode = 0;
	String type = "";
	int branch = 0;
	String state = "";
	
	
	// Report variables
	int rowCount = 0;
	int dateBegin = Integer.valueOf(String.valueOf(year) + String.valueOf(monthBegin) + String.valueOf(dayBegin));
	int dateEnd = Integer.valueOf(String.valueOf(year) + String.valueOf(monthEnd) + String.valueOf(dayEnd));

	
	public int managePTD(){		
		// Step A - Request report number from End-user
		do {
			reportNumber = requestReport();
			System.out.println("\n\nThe selected report number is " + reportNumber);
			
			if (reportNumber == 0) {
				break;
			} else if ((reportNumber >= 0) && (reportNumber < 3)){
				notFinished = true;
			} else {
				System.out.println("The requested number is not valid");
				notFinished = true;
			}		


			
			// Step B - Get report parameters from End-user
			switch (reportNumber){
			// Monthly Transactions For Customers In Zip Code For A Month And Year
			// Get zip code from End-User			
			case 1: month = requestMonth("Enter month"); 
						zipCode = requestZipCode("Enter five digit Zipcode"); 
						break;
					
			// Transaction Totals By Type Report					
			case 2: type = requestTransactionType("Enter transaction type"); 
					break;
					
			// Transactions Totals By Branch and State Report
			// Get branch and state from End-user					
			case 3: branch = requestBranch("Enter branch number"); 
					state = requestState("Enter state");
					break;
			default: System.out.println("Error in processing");
		}

			// Step C - Connect to database and display report
			performQueryWithJDBC() ;		
	
		}while (notFinished == true);
		return reportNumber;
	}
	
	/* Display Transaction Detail Reoprt Menu and retrieve the 
	 * report request number from the End-user.
	 * 
	 * This process is active to accept request and displays the
	 * menu until the End-user enters 0 as the number which indicates
	 * the End-user is finished.
	 */
	public static int requestReport() {
		boolean keepActive = true;
		boolean selectedReport = false;
		int requestedNumber;
		String menu_message = "\n\nAvailable Transaction Requests are: "
				+ "Number\tName"
				+ "\n1. Monthly Transactions For Customers In Zip Code"
				+ "\n2. Transaction Totals By Type Report"
				+ "\n3. Transactions Totals By Branch and State Report"
				+ "\n0. Finished"
				+ "\n\nEnter selected menu number: ";

		do {
			Scanner input = new Scanner(System.in);
			System.out.print(menu_message);
			requestedNumber = input.nextInt();
			if (requestedNumber == 0) {
				System.out.println("Processing stopped as requested by End-user");
				selectedReport = false;
			}
			else if ((requestedNumber > 0) && (requestedNumber < 4)){
					selectedReport = true;
			}else {
				System.out.println("A requested number is not valid");
			}
		}while (selectedReport == true);	
		return requestedNumber;
	}
	
	//Retrieves the calendar month from the End-user.
	public static int requestMonth(String message) {
			System.out.println(message);
			Scanner inputInt = new Scanner(System.in);
			boolean validMonth = false;
	    	int inputMonth;
		    do {
		    	System.out.println(message);
		    	inputMonth = inputInt.nextInt();
		    	if ((inputMonth > 0) && inputMonth <13) {
		    		validMonth = true;
		    	} else {
		    		System.out.println("For month the value must be between 1 and 12");
		    	}
			}while(validMonth == false);
		    return inputMonth;
		}

	//Retrieves the zip code from the End-user.
	static public int requestZipCode(String message) {
		System.out.println(message);
		Scanner inputInt = new Scanner(System.in);
		boolean validZip = false;
    	int inputZip;
	    do {
	    	System.out.println(message);
	    	inputZip = inputInt.nextInt();
	    	if ((inputZip > 0) && inputZip < 9999999) {
	    		validZip = true;
	    	} else {
	    		System.out.println("Zip code not vaild\n");
	    	}
		}while(validZip = false);
	    return inputZip;
	}

	//Retrieves the transaction type from the End-user.
	static public String requestTransactionType(String message) {
		System.out.println(message);
		Scanner inputString = new Scanner(System.in);
		boolean validType = false;
    	String inputType;
	    do {
	    	System.out.println(message);
	    	inputType = inputString.next();
	    	if ((inputType.length() > 0) && (inputType.length() < 3)) {
	    		validType = true;
	    	} else {
	    		System.out.println("State not valid\n");
	    	}
		}while(validType == false);
	    return inputType;
	}	

	//Retrieves the branch code from the End-user.	
	static public int requestBranch(String message) {

		System.out.println(message);
		Scanner inputInt = new Scanner(System.in);
		boolean validBranch = false;
    	int inputBranch;
	    do {
	    	System.out.println(message);
	    	inputBranch = inputInt.nextInt();
	    	if (inputBranch < 250) {
	    		validBranch = true;
	    	} else {
	    		System.out.println("Type not valid\n");
	    	}
		}while(validBranch == false);
	    return inputBranch;
	}

	//Retrieves the state from the End-user.	
	static public String requestState(String message) {
		System.out.println(message);
		Scanner inputString = new Scanner(System.in);
		boolean validState = false;
    	String inputState;
	    do {
	    	System.out.println(message);
	    	inputState = inputString.next();
	    	if ((inputState.length() > 0) && (inputState.length() < 3)) {
	    		validState = true;
	    	} else {
	    		System.out.println("State not valid\n");
	    	}
		}while(validState == false);
	    return inputState;
	}	
	
	// Convert integer to month name
	public String getMonth(int month) {
	    return new DateFormatSymbols().getMonths()[month-1];
	}
	
	
	public int performQueryWithJDBC() {
	
    try {
		/* Step 1 - Allocate a database 'Connection' object 
		 * MySQL: "jdbc:mysql://hostname:port/databaseName", "username", password"
		 */
		conn = DriverManager.getConnection(connection, user, password);
		System.out.println("Database connection successful!! \n"); 
		
		/* Step 2 - Allocate a 'Statement' object in the Connection
		 * This process uses a prepareStatement object to create the select and 
		 * update statements in order to retrieve the desired information or updated 
		 * the customer information. Inside of the case block, a tag marks the code for Step 2.
		 */

		/* Step 3 - Execution of the prepared statement occurs through the ExecuteQuery method of
		 * the ResultSet rs object statement submission of the SQL SELECT or the UPDATE statement.
		 * Inside of the case block, a tag marks the code for Step 3.
		 */
		
		/* Step 4 - The statements in the while block map the returned data in the ResultSet by 
		 * scrolling the cursor forward via next().  For each row, retrieve the contents of the
		 * cells with getXxx(columnName) are assigned to a variable. Inside of the case block, a
		 * tag marks the code for Step 4.
		 */
		switch(reportNumber) {
		// Create query and retrieve results for Monthly Transactions For Customers In Zip Code"
		case 1:
			// Step 2
			SQL = "select TRANSACTION_ID, DAY, MONTH, YEAR, CREDIT_CARD_NO, CUST_SSN, BRANCH_CODE, TRANSACTION_TYPE, TRANSACTION_VALUE "
					+ "from CDW_SAPP_CREDITCARD "
					+ "where MONTH = ? AND YEAR = ? ";
			
			// Echo For debugging
			System.out.println("The SQL query is: " + SQL + "\n"); 
			// Remove statements above before going into production
			
			pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, month);
			pstmt.setInt(2, 2018);
			
			//Step 3
			rs = pstmt.executeQuery(SQL);
		 
			 // Step 4
			 System.out.println("The records selected are:");
			 rowCount = 0;
			 while(rs.next()) {
				 int transactionID = rs.getInt("TRANSACTION_ID");
				 int transactionDay = rs.getInt("DAY");
				 int transactionMonth = rs.getInt("MONTH");
				 int transactionYear = rs.getInt("YEAR");
				 String creditCardNumber = rs.getString("CREDIT_CARD_NO");
				 int customerSSN = rs.getInt("CUST_SSN");
				 int branch = rs.getInt("BRANCH_CODE");
				 String transactionType = rs.getString("TRANSACTION_TYPE");
				 double tranasactionValue = rs.getDouble("TRANSACTION_VALUE");
				 
				 System.out.println("Transactions for a customer in " + transactionMonth +  " " + year);
				 System.out.println(transactionID + ", " + transactionDay + ", " + transactionMonth + ", "  + transactionYear
					 + ", " + creditCardNumber + ", " + customerSSN + ", " + branch  + ", " + transactionType + ", " + tranasactionValue);
				 ++rowCount;
			 }
			 System.out.println("Total number of records = " + rowCount);
			break;

		// Create query for Transaction Totals By Type Report
		case 2:
			// Step 2
			SQL = "select TRANSACTION_TYPE, count(TRANSACTION_TYPE), sum(TRANSACTION_VALUE) from CDW_SAPP_CREDITCARD where TRANSACTION_TYPE = ? group by TRANSACTION_TYPE ";
			
			// Echo For debugging
			System.out.println("The SQL query is: " + SQL + "\n"); 
			// Remove statements above before going into production

			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, type);
			
			// Step 3
		    rs = pstmt.executeQuery();
		 
		    // Step 4
			 System.out.println("Transaction Totals By Type Report: " + type);
			 rowCount = 0;
			 while(rs.next()) {
				 String transactionType = rs.getString("TRANSACTION_TYPE");
				 int transactionTypeCount = rs.getInt("count(TRANSACTION_TYPE)");
				 double tranasactionValue = rs.getDouble("sum(TRANSACTION_VALUE)");
			
				 System.out.println(transactionType + ", " + transactionTypeCount + ", " + tranasactionValue);
			     ++rowCount;
			 }
			 System.out.println("Total number of records = " + rowCount);
			 break;  			

		// Create query for Transaction Transactions Totals By Branch and State Report
		case 3:
			// Step 2
			SQL = "select a.BRANCH_STATE, a.BRANCH_CODE, count(b.TRANSACTION_VALUE), sum(b.TRANSACTION_VALUE) from CDW_SAPP_BRANCH a JOIN CDW_SAPP_CREDITCARD b on (a.BRANCH_CODE = b.BRANCH_CODE) where a.BRANCH_STATE = ? group by a.BRANCH_STATE, a.BRANCH_CODE";
			
			// Echo For debugging
			System.out.println("The SQL query is: " + SQL + "\n"); 
			// Remove statements above before going into production

			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, state);

	        // Step 3
			ResultSet rs = pstmt.executeQuery();
		 
			// Step 4
			 rowCount = 0;
			 while(rs.next()) {
				 String transactionState = rs.getString("a.BRANCH_STATE");
				 String transactionBranch = rs.getString("a.BRANCH_CODE");
				 int transactionCount = rs.getInt("count(b.TRANSACTION_VALUE)");
				 double tranasactionTotal = rs.getDouble("sum(b.TRANSACTION_VALUE)");
				
				 System.out.println(transactionState + ", " + transactionBranch + ", " + transactionCount + ", "  + tranasactionTotal);
				 ++rowCount;
			 }
			 System.out.println("Total number of records = " + rowCount);
				 break;  			
			
			default:
				// If you arrived here, an error exist, leave the process
					break;
					
				}
				return outcomeOfQuery = 1;
		} catch (Exception exc) {
			exc.printStackTrace();
		}
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				
				if (pstmt != null) {
					pstmt.close();
				}
				
				if (conn != null) {
					conn.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			  }
		}
	}

}