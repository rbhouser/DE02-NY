/*
 * ----------------------------------------------------------------------------------------------------------------------------------------------------------
 * Name: Robert B. Houser
 * Date Due: June 25, 2016
 * Course: Data Engineering
 * Project: Case Study  
 * 
 * File: Report Transaction Data
 * 
 * ----------------------------------------------------------------------------------------------------------------------------------------------------------
*/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.DateFormatSymbols;

public class JdbcTest {

	public static void main(String[] args) {

			// JDBC objects and variables
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String database = "cdw_sapp";
			String user = "root";
			String password = "Maat4one";
			String connection = "jdbc:mysql://localhost:3306/" + database + "?useSSL=false";
			String SQL = "";		

			// Parameter variables
			String creditCard = "4210653349028689";
			int socialSecurity = 123459988;
			int year = 2018;
			int month = 3;
			int dayBegin = 1;
			int dayEnd = 28;
			int monthBegin = 01;
			int monthEnd = 07;
			String type = "Healthcare";
			String state = "NY";
			
			// Report variables
			int rowCount = 0;
			int dateBegin = Integer.valueOf(String.valueOf(year) + String.valueOf(monthBegin) + String.valueOf(dayBegin));
			int dateEnd = Integer.valueOf(String.valueOf(year) + String.valueOf(monthEnd) + String.valueOf(dayEnd));
			String reportMonth = getMonth(month);
			
			try {
				// 1. Get connection to database
				conn = DriverManager.getConnection(connection, user, password);
				System.out.println("Database connection successful!! \n");
				
				// 2. Create a statement
				// Step 2
				SQL = "select TRANSACTION_TYPE, count(TRANSACTION_TYPE), sum(TRANSACTION_VALUE) from CDW_SAPP_CREDITCARD where TRANSACTION_TYPE = ? group by TRANSACTION_TYPE ";
				
				// Echo For debugging
				System.out.println("The SQL query is: " + SQL + "\n"); 
				// Remove statements above before going into production

				pstmt = conn.prepareStatement(SQL);
				pstmt.setString(1, type);
			
				// Step 3
				rs = pstmt.executeQuery();
			 
				 // Step 4
				 System.out.println("Transaction Totals By Type Report: " + type);
				 rowCount = 0;
				 while(rs.next()) {
					 String transactionType = rs.getString("TRANSACTION_TYPE");
					 int transactionTypeCount = rs.getInt("count(TRANSACTION_TYPE)");
					 double tranasactionValue = rs.getDouble("sum(TRANSACTION_VALUE)");
				
					 System.out.println(transactionType + ", " + transactionTypeCount + ", " + tranasactionValue);
				     ++rowCount;
				 }
				 System.out.println("Total number of records = " + rowCount);
				 
			} catch (Exception exc) {
				exc.printStackTrace();
			}
			finally {
				try {
					if (rs != null) {
						rs.close();
					}
					
					if (pstmt != null) {
						pstmt.close();
					}
					
					if (conn != null) {
						conn.close();
					}
				} catch (Exception exc) {
					exc.printStackTrace();
				  }
			}
	}

	// Below are methods for displaying results on the console
	
	public static String getMonth(int month) {
	    return new DateFormatSymbols().getMonths()[month-1];
	}
}
